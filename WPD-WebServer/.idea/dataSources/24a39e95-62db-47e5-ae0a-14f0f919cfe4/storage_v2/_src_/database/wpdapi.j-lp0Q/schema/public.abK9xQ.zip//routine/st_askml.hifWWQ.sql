create function st_askml(text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_AsKML(2, $1::public.geometry, 15, null);
$$;

alter function st_askml(text) owner to wpdadmin;

