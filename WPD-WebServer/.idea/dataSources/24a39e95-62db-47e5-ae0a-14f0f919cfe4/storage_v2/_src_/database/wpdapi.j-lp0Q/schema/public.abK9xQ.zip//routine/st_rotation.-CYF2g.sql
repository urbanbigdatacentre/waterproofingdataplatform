create function st_rotation(raster) returns double precision
    language sql
as
$$
SELECT ( public.ST_Geotransform($1)).theta_i
$$;

comment on function st_rotation(raster) is 'args: rast - Returns the rotation of the raster in radian.';

alter function st_rotation(raster) owner to wpdadmin;

