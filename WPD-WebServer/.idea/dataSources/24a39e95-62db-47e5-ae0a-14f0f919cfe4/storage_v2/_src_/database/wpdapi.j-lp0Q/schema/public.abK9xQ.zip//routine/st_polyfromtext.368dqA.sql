create function st_polyfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1, $2)) = 'POLYGON'
	THEN public.ST_GeomFromText($1, $2)
	ELSE NULL END
$$;

alter function st_polyfromtext(text, integer) owner to wpdadmin;

