create function st_approxquantile(rastertable text, rastercolumn text, exclude_nodata_value boolean, quantile double precision DEFAULT NULL::double precision) returns double precision
    stable
    language sql
as
$$
SELECT ( public._ST_quantile($1, $2, 1, $3, 0.1, ARRAY[$4]::double precision[])).value
$$;

alter function st_approxquantile(text, text, boolean, double precision) owner to wpdadmin;

