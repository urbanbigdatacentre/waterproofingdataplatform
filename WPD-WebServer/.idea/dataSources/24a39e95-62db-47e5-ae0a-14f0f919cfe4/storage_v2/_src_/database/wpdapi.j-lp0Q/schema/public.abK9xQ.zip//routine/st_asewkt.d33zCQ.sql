create function st_asewkt(text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_AsEWKT($1::public.geometry);
$$;

alter function st_asewkt(text) owner to wpdadmin;

