create function raster_left(raster, raster) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$
select $1::geometry << $2::geometry
$$;

alter function raster_left(raster, raster) owner to wpdadmin;

