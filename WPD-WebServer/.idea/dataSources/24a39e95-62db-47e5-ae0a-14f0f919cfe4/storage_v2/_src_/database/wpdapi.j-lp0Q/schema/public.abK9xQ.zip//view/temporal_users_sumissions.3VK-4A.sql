create view temporal_users_sumissions(id, total, idusersinformer, latitude, longitude, geom) as
SELECT max(formsanswers.id) AS id,
       count(*)             AS total,
       formsanswers.idusersinformer,
       formsanswers.latitude,
       formsanswers.longitude,
       formsanswers.geom
FROM formsanswers
WHERE formsanswers.idusersinformer <> 1
  AND formsanswers.idforms > 5
GROUP BY formsanswers.idusersinformer, formsanswers.latitude, formsanswers.longitude, formsanswers.geom;

alter table temporal_users_sumissions
    owner to wpdadmin;

