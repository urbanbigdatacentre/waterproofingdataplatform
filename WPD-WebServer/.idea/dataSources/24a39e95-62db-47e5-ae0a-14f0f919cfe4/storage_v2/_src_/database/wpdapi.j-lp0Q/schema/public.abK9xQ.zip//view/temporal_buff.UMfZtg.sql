create view temporal_buff(id, geom) as
SELECT 1                                                                                           AS id,
       st_buffer(st_geogfromtext('POINT(-46.5281733 -23.6444933)'::text), 50000::double precision) AS geom;

alter table temporal_buff
    owner to wpdadmin;

