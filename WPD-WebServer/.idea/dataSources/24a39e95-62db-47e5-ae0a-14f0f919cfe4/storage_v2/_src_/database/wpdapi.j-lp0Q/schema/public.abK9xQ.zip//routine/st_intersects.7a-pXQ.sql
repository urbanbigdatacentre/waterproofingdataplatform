create function st_intersects(geography, geography) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Distance($1, $2, 0.0, false) < 0.00001
$$;

comment on function st_intersects(geography, geography) is 'args: geogA, geogB - Returns TRUE if the Geometries/Geography "spatially intersect in 2D" - (share any portion of space) and FALSE if they dont (they are Disjoint). For geography -- tolerance is 0.00001 meters (so any points that close are considered to intersect)';

alter function st_intersects(geography, geography) owner to wpdadmin;

