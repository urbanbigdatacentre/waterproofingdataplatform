create function st_distinct4ma(matrix double precision[], nodatamode text, VARIADIC args text[]) returns double precision
    immutable
    parallel safe
    language sql
as
$$
SELECT COUNT(DISTINCT unnest)::float FROM unnest($1)
$$;

alter function st_distinct4ma(double precision[], text, text[]) owner to wpdadmin;

